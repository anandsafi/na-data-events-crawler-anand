// .github/scripts/refresh-events.mjs
//
// Data Dispatch — daily refresh + discovery
// ==========================================
// 1) Pull from curated feeds (free)
// 2) Crawl Google via SerpAPI or Brave Search across a (city × topic) matrix,
//    3 pages deep per query (30 results)
// 3) Normalize, filter (blocklist, stopwords, date required), and fuzzy-dedupe
//    against everything already in events.json
// 4) Append net-new entries with discovered_at = now()
// 5) Write a markdown discovery report so you can see what was rejected & why
//
// Run modes (via env):
//   SEARCH_BACKEND=serpapi  (default if SERPAPI_KEY set)
//   SEARCH_BACKEND=brave    (if BRAVE_KEY set)
//   SEARCH_BACKEND=none     (skip Google entirely; feeds only)
//   DEEP_CRAWL=1            (5 pages per query instead of 3)
//
// Cost discipline:
//   default = 3 pages × ~15 queries = 45 search-API calls per run.
//   At daily cadence: ~1,350/mo. SerpAPI Developer plan covers this.
//   Brave free tier (2,000/mo) also covers it.

import fs from 'node:fs/promises';
import path from 'node:path';
import fetch from 'node-fetch';
import { XMLParser } from 'fast-xml-parser';

// ---------- config ----------
const ROOT = process.cwd();
const FILE = path.join(ROOT, 'events.json');
const REPORT = path.join(ROOT, 'discovery-report.md');

const TARGET_CITIES = ['Ottawa', 'Toronto', 'Montréal'];
const CITY_ALIASES  = { 'Montreal': 'Montréal' };

const TOPIC_TERMS = [
  'data engineering conference',
  'AI summit',
  'machine learning meetup',
  'data analytics conference',
  'AI conference 2026',
  'data conference 2027',
];

const CONF_QUERIES = [
  'new data conference 2026 USA Canada announced',
  'new AI conference 2027 Canada call for papers',
  'data engineering summit 2026 USA',
  'AI infrastructure conference 2026',
  'analytics engineering conference 2026',
];

// Domains we trust → can be added even without an explicit date in snippet.
const DOMAIN_ALLOWLIST = new Set([
  'snowflake.com', 'databricks.com', 'getdbt.com', 'mila.quebec',
  'vectorinstitute.ai', 'ivado.ca', 'aitinkerers.org',
  'torontomachinelearning.com', 'bigdatasummitcanada.com',
  'reinvent.awsevents.com', 'cloud.withgoogle.com', 'neurips.cc',
  'icml.cc', 'iclr.cc', 'allinevent.ai', 'worldsummit.ai',
  'event.idc.com', 'createwith.com',
]);

// Domains that mostly produce SEO-spam academic conferences or duplicated listings.
const DOMAIN_BLOCKLIST = new Set([
  'conferencealerts.in', 'conferencealerts.co.in', 'conferencealert.co.in',
  'allconferencealert.com', 'conferenceindex.org', 'internationalconferencealerts.com',
  'waset.org', 'researchplus.co', '10times.com',  // mixed quality
  'webmobi.com', 'cantonfair.net', 'showsbee.com', 'stayhappening.com',
  'allevents.in', 'conferences-basecamp.informatik.uni-hamburg.de',
]);

// Title patterns that signal listicles / non-events; reject.
const TITLE_STOPWORDS = [
  /^upcoming /i, /^top \d+ /i, /^best /i, /\bguide to\b/i,
  /^list of /i, /\bcalendar\b.*\bconferences\b/i, /^conferences? in \b/i,
  /^find /i, /^explore /i, /^discover /i,
];

// ---------- curated feeds (free, run every day) ----------
const FEED_SOURCES = [
  { id: 'ait-ottawa',  city: 'Ottawa',   url: 'https://ottawa.aitinkerers.org/' },
  { id: 'ait-toronto', city: 'Toronto',  url: 'https://toronto.aitinkerers.org/' },
  { id: 'mila',        city: 'Montréal', url: 'https://mila.quebec/en/events' },
  { id: 'vector',      city: 'Toronto',  url: 'https://vectorinstitute.ai/feed/' },
];

// ---------- utilities ----------
const nowISO = () => new Date().toISOString();
const today  = nowISO().slice(0, 10);

const log = { added: [], rejected: [], sources: {} };

function canonicalUrl(raw) {
  try {
    const u = new URL(raw);
    let host = u.hostname.toLowerCase().replace(/^www\./, '');
    let pathname = u.pathname.replace(/\/+$/, '') || '/';
    return (`${host}${pathname}`).toLowerCase();
  } catch { return null; }
}

function rootDomain(raw) {
  try {
    return new URL(raw).hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}

function titleKey(s) {
  if (!s) return '';
  return s.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // strip accents
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\b(the|a|an|to|of|for|in|on|at|by|with|and|or|2026|2027)\b/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function fuzzySimilar(a, b) {
  const ka = titleKey(a), kb = titleKey(b);
  if (!ka || !kb) return false;
  if (ka === kb) return true;
  // Substring containment with length sanity
  const [s, l] = ka.length < kb.length ? [ka, kb] : [kb, ka];
  if (s.length >= 12 && l.includes(s)) return true;
  // Token overlap ratio
  const ta = new Set(ka.split(' ')), tb = new Set(kb.split(' '));
  const overlap = [...ta].filter((t) => tb.has(t)).length;
  const minSize = Math.min(ta.size, tb.size);
  return minSize >= 3 && overlap / minSize >= 0.75;
}

function extractDate(text) {
  if (!text) return null;
  // ISO first
  const m = text.match(/\b(20\d\d)-(\d{2})-(\d{2})\b/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  const months = {
    jan:'01', feb:'02', mar:'03', apr:'04', may:'05', jun:'06',
    jul:'07', aug:'08', sep:'09', sept:'09', oct:'10', nov:'11', dec:'12',
  };
  const monthRe = '(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\\.?';
  // Cross-month range FIRST: "Nov 30 - Dec 4, 2026" → start = Nov 30, 2026
  const rangeRe = new RegExp(
    `\\b${monthRe}\\s+(\\d{1,2})\\s*[\\u2013\\u2014-]\\s*${monthRe}\\s+\\d{1,2},?\\s*(20\\d\\d)\\b`,
    'i'
  );
  const m1 = text.match(rangeRe);
  if (m1) {
    const mm = months[m1[1].toLowerCase().slice(0, 4)] || months[m1[1].toLowerCase().slice(0, 3)];
    if (mm) return `${m1[4]}-${mm}-${m1[2].padStart(2, '0')}`;
  }
  // Single month / same-month range: "Sept 15-18, 2026"
  const m2 = text.match(new RegExp(
    `\\b${monthRe}\\s+(\\d{1,2})(?:\\s*[\\u2013\\u2014-]\\s*\\d{1,2})?,?\\s*(20\\d\\d)\\b`, 'i'
  ));
  if (m2) {
    const mm = months[m2[1].toLowerCase().slice(0, 4)] || months[m2[1].toLowerCase().slice(0, 3)];
    if (mm) return `${m2[3]}-${mm}-${m2[2].padStart(2, '0')}`;
  }
  // Day Month Year: "16 June 2026"
  const m3 = text.match(new RegExp(
    `\\b(\\d{1,2})\\s+${monthRe}\\s+(20\\d\\d)\\b`, 'i'
  ));
  if (m3) {
    const mm = months[m3[2].toLowerCase().slice(0, 4)] || months[m3[2].toLowerCase().slice(0, 3)];
    if (mm) return `${m3[3]}-${mm}-${m3[1].padStart(2, '0')}`;
  }
  return null;
}

function detectCity(text) {
  if (!text) return null;
  for (const city of TARGET_CITIES) {
    if (new RegExp(`\\b${city}\\b`, 'i').test(text)) return city;
  }
  for (const [alias, canonical] of Object.entries(CITY_ALIASES)) {
    if (new RegExp(`\\b${alias}\\b`, 'i').test(text)) return canonical;
  }
  return null;
}

function slugify(s) {
  return (s || '').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}

function makeId({ city, name, starts }) {
  const prefix = city ? city.slice(0, 3).toLowerCase() : 'conf';
  const ymd = starts ? starts.replace(/-/g, '') : 'tba';
  return `${prefix}-${slugify(name)}-${ymd}`;
}

async function safe(label, fn) {
  try { return await fn(); }
  catch (e) {
    console.warn(`[warn] ${label}:`, e.message);
    log.sources[label] = { error: e.message };
    return [];
  }
}

// ---------- HTML scraping (curated feeds) ----------
function extractFromHTML(html, city, sourceUrl) {
  const found = [];
  const re = /<a\b[^>]*href="([^"]+)"[^>]*>([^<]{8,160})<\/a>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const [, href, text] = m;
    if (!/event|meetup|conference|summit|workshop|talks?|symposium/i.test(text + ' ' + href)) continue;
    const ctx = html.slice(Math.max(0, m.index - 240), m.index + 360);
    const starts = extractDate(ctx);
    const url = href.startsWith('http') ? href : new URL(href, sourceUrl).toString();
    found.push({
      name: text.trim().replace(/\s+/g, ' '),
      url, city, starts,
      category: 'city',
      blurb: '',
      snippet: ctx.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200),
      _source: rootDomain(sourceUrl),
    });
  }
  return found;
}

function extractFromFeed(xml, city, sourceUrl) {
  let parsed;
  try { parsed = new XMLParser({ ignoreAttributes: false }).parse(xml); }
  catch { return []; }
  const items = parsed?.rss?.channel?.item || parsed?.feed?.entry || [];
  const arr = Array.isArray(items) ? items : [items];
  return arr.flatMap((it) => {
    const name = String(it.title?.['#text'] || it.title || '').trim();
    if (!name) return [];
    if (!/event|conference|summit|workshop|talks|remarkable|symposium/i.test(name)) return [];
    const link = it.link?.['@_href'] || it.link || it.guid || '';
    const desc = it.description?.['#text'] || it.description || it.summary || '';
    return [{
      name, url: String(link),
      city, category: 'city',
      starts: extractDate(`${name} ${desc}`),
      blurb: String(desc).replace(/<[^>]+>/g, ' ').slice(0, 240),
      snippet: '',
      _source: rootDomain(sourceUrl),
    }];
  });
}

// ---------- Google search backends ----------
async function searchSerpApi(query, page) {
  const key = process.env.SERPAPI_KEY;
  if (!key) return [];
  const u = new URL('https://serpapi.com/search.json');
  u.searchParams.set('engine', 'google');
  u.searchParams.set('q', query);
  u.searchParams.set('tbs', 'qdr:m');       // last month — fresh content only
  u.searchParams.set('num', '10');
  u.searchParams.set('start', String(page * 10));
  u.searchParams.set('api_key', key);
  const r = await fetch(u);
  if (!r.ok) throw new Error(`serpapi ${r.status}`);
  const j = await r.json();
  return (j.organic_results || []).map((x) => ({
    title: x.title, link: x.link, snippet: x.snippet || '',
  }));
}

async function searchBrave(query, page) {
  const key = process.env.BRAVE_KEY;
  if (!key) return [];
  const u = new URL('https://api.search.brave.com/res/v1/web/search');
  u.searchParams.set('q', query);
  u.searchParams.set('count', '20');
  u.searchParams.set('offset', String(page * 20));
  u.searchParams.set('freshness', 'pm');     // past month
  const r = await fetch(u, { headers: { 'X-Subscription-Token': key, 'Accept': 'application/json' } });
  if (!r.ok) throw new Error(`brave ${r.status}`);
  const j = await r.json();
  return (j.web?.results || []).map((x) => ({
    title: x.title, link: x.url, snippet: x.description || '',
  }));
}

function pickBackend() {
  const forced = process.env.SEARCH_BACKEND;
  if (forced === 'none') return null;
  if (forced === 'brave' || (!forced && process.env.BRAVE_KEY && !process.env.SERPAPI_KEY)) return searchBrave;
  if (forced === 'serpapi' || process.env.SERPAPI_KEY) return searchSerpApi;
  if (process.env.BRAVE_KEY) return searchBrave;
  return null;
}

async function crawlGoogle(queries, pages) {
  const backend = pickBackend();
  if (!backend) {
    console.log('[google] no key set, skipping search');
    return [];
  }
  const out = [];
  for (const q of queries) {
    const results = [];
    for (let p = 0; p < pages; p++) {
      const batch = await safe(`google[${q}|p${p}]`, () => backend(q, p));
      if (!batch.length) break;
      results.push(...batch);
    }
    log.sources[`google:${q}`] = { results: results.length };
    for (const r of results) {
      const city = detectCity(`${r.title} ${r.snippet}`);
      const starts = extractDate(`${r.title} ${r.snippet}`);
      out.push({
        name: r.title, url: r.link,
        city, starts,
        category: city ? 'city' : 'conference',
        blurb: r.snippet,
        snippet: r.snippet,
        _source: rootDomain(r.link),
        _query: q,
      });
    }
  }
  return out;
}

// ---------- filter pipeline ----------
function passesFilter(cand, existingIndex) {
  // Blocklist
  if (DOMAIN_BLOCKLIST.has(cand._source)) return { ok: false, reason: 'blocklist:' + cand._source };
  // Stopwords (listicles, guide pages)
  if (TITLE_STOPWORDS.some((re) => re.test(cand.name))) return { ok: false, reason: 'stopword-title' };
  // Must have URL + name
  const canon = canonicalUrl(cand.url);
  if (!canon || !cand.name || cand.name.length < 6) return { ok: false, reason: 'invalid' };
  // Require date OR trusted domain (allowlisted)
  const trusted = DOMAIN_ALLOWLIST.has(cand._source);
  if (!cand.starts && !trusted) return { ok: false, reason: 'no-date-untrusted' };
  // Drop past events
  if (cand.starts && cand.starts < today) return { ok: false, reason: 'past:' + cand.starts };
  // URL exact dedupe
  if (existingIndex.urls.has(canon)) return { ok: false, reason: 'dup-url' };
  // Title fuzzy dedupe (per-city scoped — same name in different cities is allowed)
  const cityBucket = existingIndex.titlesByCity.get(cand.city || '_conf') || [];
  for (const t of cityBucket) {
    if (fuzzySimilar(t, cand.name)) return { ok: false, reason: 'dup-title:' + t.slice(0, 40) };
  }
  return { ok: true };
}

function buildIndex(events) {
  const urls = new Set();
  const titlesByCity = new Map();
  for (const e of events) {
    const c = canonicalUrl(e.url); if (c) urls.add(c);
    const key = e.city || '_conf';
    if (!titlesByCity.has(key)) titlesByCity.set(key, []);
    titlesByCity.get(key).push(e.name);
  }
  return { urls, titlesByCity };
}

// ---------- main ----------
console.log(`[refresh] ${nowISO()}`);

const existing = JSON.parse(await fs.readFile(FILE, 'utf-8'));
const existingIndex = buildIndex(existing.events);

const candidates = [];

// 1. Curated feeds (always)
for (const s of FEED_SOURCES) {
  const html = await safe(s.id, async () => {
    const r = await fetch(s.url, { headers: { 'User-Agent': 'data-dispatch-bot/2.0' } });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.text();
  });
  if (!html) continue;
  const out = s.url.match(/feed|\.xml(\?|$)/) ? extractFromFeed(html, s.city, s.url) : extractFromHTML(html, s.city, s.url);
  log.sources[s.id] = { results: out.length };
  candidates.push(...out);
}

// 2. Google crawl (city × topic + bare conference queries)
const pages = process.env.DEEP_CRAWL === '1' ? 5 : 3;
const googleQueries = [
  ...TARGET_CITIES.flatMap((c) => TOPIC_TERMS.map((t) => `${t} ${c} 2026`)),
  ...CONF_QUERIES,
];
console.log(`[google] backend=${pickBackend()?.name || 'none'} queries=${googleQueries.length} pages=${pages}`);
candidates.push(...await crawlGoogle(googleQueries, pages));

console.log(`[refresh] candidates=${candidates.length}`);

// 3. Filter + dedupe
const accepted = [];
for (const c of candidates) {
  const r = passesFilter(c, existingIndex);
  if (!r.ok) {
    log.rejected.push({ name: c.name, url: c.url, src: c._source, reason: r.reason });
    continue;
  }
  // Promote to canonical entry
  const id = makeId(c);
  if (existing.events.some((e) => e.id === id)) {
    log.rejected.push({ name: c.name, url: c.url, src: c._source, reason: 'dup-id' });
    continue;
  }
  const entry = {
    id,
    city: c.city,
    category: c.category,
    name: c.name.replace(/\s+/g, ' ').trim(),
    when: c.starts || 'TBA',
    starts: c.starts || undefined,
    where: undefined,
    url: c.url,
    blurb: (c.blurb || '').replace(/\s+/g, ' ').trim().slice(0, 280),
    flags: [],
    discovered_at: nowISO(),
    _provenance: { source: c._source, query: c._query || null },
  };
  existing.events.push(entry);
  accepted.push(entry);
  // Update index for in-batch dedupe
  const canon = canonicalUrl(entry.url); if (canon) existingIndex.urls.add(canon);
  const key = entry.city || '_conf';
  if (!existingIndex.titlesByCity.has(key)) existingIndex.titlesByCity.set(key, []);
  existingIndex.titlesByCity.get(key).push(entry.name);
  log.added.push({ id: entry.id, name: entry.name, url: entry.url, src: c._source });
}

// 4. Bump version, write events.json
existing.previous_version = existing.version;
existing.version = `${today}-auto`;
existing.generated_at = nowISO();
await fs.writeFile(FILE, JSON.stringify(existing, null, 2) + '\n');

// 5. Write discovery report
const groupRejected = log.rejected.reduce((acc, r) => {
  const key = r.reason.split(':')[0];
  (acc[key] = acc[key] || []).push(r);
  return acc;
}, {});
const report = [
  `# Discovery Report — ${nowISO()}`,
  ``,
  `**Candidates examined:** ${candidates.length}  `,
  `**Accepted:** ${accepted.length}  `,
  `**Rejected:** ${log.rejected.length}  `,
  `**Total events after merge:** ${existing.events.length}`,
  ``,
  `## Source breakdown`,
  ...Object.entries(log.sources).map(([k, v]) => `- \`${k}\` → ${v.results ?? `error: ${v.error}`}`),
  ``,
  `## Accepted (${accepted.length})`,
  ...accepted.map((e) => `- **${e.name}** — \`${e.id}\` · ${e.starts || 'no date'} · ${e._provenance?.source}  \n  ${e.url}`),
  ``,
  `## Rejected by reason`,
  ...Object.entries(groupRejected)
    .sort(([, a], [, b]) => b.length - a.length)
    .map(([reason, items]) => [
      `### ${reason} (${items.length})`,
      ...items.slice(0, 30).map((r) => `- ${r.name?.slice(0, 80)} \`${r.src}\``),
      items.length > 30 ? `- _…and ${items.length - 30} more_` : '',
    ].filter(Boolean).join('\n')),
  ``,
  `_Tune \`DOMAIN_BLOCKLIST\` / \`DOMAIN_ALLOWLIST\` / \`TITLE_STOPWORDS\` in \`refresh-events.mjs\` based on what you see here._`,
].join('\n');
await fs.writeFile(REPORT, report);

// Strip _provenance from final entries (used for report only)
existing.events.forEach((e) => { delete e._provenance; });
await fs.writeFile(FILE, JSON.stringify(existing, null, 2) + '\n');

console.log(`[refresh] done. +${accepted.length} new, ${log.rejected.length} rejected. version=${existing.version}`);
